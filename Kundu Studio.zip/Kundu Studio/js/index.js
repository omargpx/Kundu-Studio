let closeLogin = document.getElementById('close-login');
closeLogin.addEventListener('click', closeLog);
let closeRegistro = document.getElementById('close-registro');
closeRegistro.addEventListener('click', closeRegis);

function closeLog(e) {
    e.preventDefault();
    document.getElementById('popup-login').style.display = "none";
}

function closeRegis(e) {
    e.preventDefault();
    document.getElementById('popup-registro').style.display = "none";
}

function openLogin() {
    document.getElementById('popup-registro').style.display = "none";
    let open = document.getElementById('popup-login').style.display = "grid";
    document.getElementById('popup-login').style.transition = open + " .3s ease-out";
}

function openRegistro() {
    document.getElementById('popup-login').style.display = "none";
    let open = document.getElementById('popup-registro').style.display = "grid";
    document.getElementById('popup-registro').style.transition = open + ".3s ease-out";
}